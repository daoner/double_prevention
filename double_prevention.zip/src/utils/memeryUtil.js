export default {
    user: {}
}

/**
 * user{
 *  id
 *  deptid
 *  role 
 * }
 */