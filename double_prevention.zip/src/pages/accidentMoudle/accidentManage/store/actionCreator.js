import * as actionTypes from './actionTypes';


export const changeSubmitSuccess = (submitSuccess)=>({
    type: actionTypes.CHANGE_SUBMIT_SUCCESS,
    submitSuccess
})