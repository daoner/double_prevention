export const CHANGE_CHECKTABLE_LIST = "checkTable/change_checkTable_list";        //改变显示列表内容

export const CHANGE_SUBMIT_SUCCESS = "checkTable/change_submit_success";    //改变是否提交成功

export const CHANGE_CHECKTABLE_DETAIL = 'checkTable/change_checkTable_detail'; //改变指定id的checktable的详情

