export const CHANGE_MODAL_VISIBLE = "firstIndicator/change_modal_visible";  //改变模态框显示
export const CHANGE_SELECT_LIST = "firstIndicator/change_select_list"; //改变 select   列表
export const CHANGE_CHECKTABLE_ID = "firstIndicator/change_checktable_id";  //改变table的id

export const CHANGE_FIRST_LIST ="firstIndicator/change_first_list"; //改变显示的firstlevel列表