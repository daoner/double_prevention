export const ADD_ORGANIZATION = "organization/add_organization";
export const DELETE_ORGANIZATION = "organization/delete_organization";
export const MODIGY_ORGANIZATION = "organization/modify_organization";
export const CHANGE_ORGANIZATION_LIST = "organization/change_organization_list";
export const CHANGE_PAGE = "organization/change_organization_page";     //换页的action常量
export const CHANGE_PAGE_SIZE = "organization/change_organization_page_size"; //换每页显示条数的action常量  
export const SHOW_MODAL = "organization/show_modal"; //显示模态框
export const HIDE_MODAL = "organization/hide_modal"; //隐藏模态框