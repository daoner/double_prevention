export const CHANGE_ROLE_LIST = "role/change_role_list";        //利用请求的list更新state 的action

